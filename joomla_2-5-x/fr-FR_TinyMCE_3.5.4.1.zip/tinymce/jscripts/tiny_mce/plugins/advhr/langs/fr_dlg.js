// FR lang variables - Sarki pour Joomla! FR 2011-07-17
tinyMCE.addI18n('fr.advhr_dlg',{
normal:"Normal",
width:"Largeur",
widthunits:"Unit�",
size:"Hauteur",
noshade:"Sans ombre"
});