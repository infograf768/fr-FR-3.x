// FR lang variables - Sarki pour Joomla! FR 2011-07-17
tinyMCE.addI18n('fr.emotions_dlg',{
title:"Ins\u00E9rez un \u00E9motic\u00F4ne",
desc:"Emotic\u00F4nes",
cool:"Cool",
cry:"Triste",
embarassed:"Embarass\u00E9",
foot_in_mouth:"Bouche pleine",
frown:"M\u00E9content",
innocent:"Innocent",
kiss:"Baiser",
laughing:"Content",
money_mouth:"Monnaie",
sealed:"Muet",
smile:"Sourire",
surprised:"Surpris",
tongue_out:"Coquin",
undecided:"Ind\u00E9cis",
wink:"Complice",
yell:"Furieux"
});