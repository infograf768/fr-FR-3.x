// FR lang variables - Sarki pour Joomla! FR 2011-07-17
tinyMCE.addI18n('fr.simple',{
bold_desc:"Gras (Ctrl+B)",
italic_desc:"Italique (Ctrl+I)",
underline_desc:"Soulign� (Ctrl+U)",
striketrough_desc:"Barr�",
bullist_desc:"Liste � puce",
numlist_desc:"Liste chronologique",
undo_desc:"Annuler (Ctrl+Z)",
redo_desc:"R�tablir (Ctrl+Y)",
cleanup_desc:"Nettoyer/Fermer les balises"
});